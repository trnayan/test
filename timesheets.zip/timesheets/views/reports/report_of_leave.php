<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="relative report_of_leave"class="hide reports_fr">
   <div id="report_of_leave" class="reports"></div>
</div>